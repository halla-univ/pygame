import sys, pygame
from pygame.locals import QUIT, Rect
pygame.init()
SURFACE = pygame.display.set_mode((400, 300))
FPSCLOCK = pygame.time.Clock()

logo = pygame.image.load("파이썬로고.png")
# 이미지는 한번만 불러오면 되므로 반복문 앞에서 호출한다.
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    SURFACE.fill((225, 225, 225))
    # (10, 10) 위치에 로고를 그린다
    SURFACE.blit(logo, (10, 10))

    pygame.display.update()
    FPSCLOCK.tick(30)
