import sys, pygame
from pygame.locals import QUIT, Rect
pygame.init()
SURFACE = pygame.display.set_mode((400, 200))
FPSCLOCK = pygame.time.Clock()

sysfont = pygame.font.SysFont(None, 72)
message = sysfont.render("Hello Python", True, (0, 128, 128))
message_rect = message.get_rect()
message_rect.center = (200, 100)
theta = 0
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    SURFACE.fill((255, 255, 255))
    theta += 5 # 루프 안에서 각도가 계속 증가하며 문장이 회전함
    scale = (theta % 360) / 180
    msg = pygame.transform.rotozoom(message, theta, scale)
    rect = msg.get_rect()
    rect.center = (200, 100)
    SURFACE.blit(msg, rect)
    pygame.display.update()
    FPSCLOCK.tick(10)
