import sys, pygame
from pygame.locals import QUIT 
from math import radians, cos, sin
pygame.init()
SURFACE = pygame.display.set_mode((800, 300))
FPSCLOCK = pygame.time.Clock()
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    SURFACE.fill((0,0,0))
    pygame.draw.line(SURFACE,(255,255,255),(50,100),(680,100))
    pygame.draw.line(SURFACE,(255,255,255),(50,200),(680,200))
    pointlist0, pointlist1 = [], []
    for theta in range(0, 720, 1):
        rad = radians(theta)
        pointlist0.append((rad*50+50, -sin(rad)*50+100))
        pointlist1.append((rad*50+50, -cos(rad)*50+200))
    pygame.draw.lines(SURFACE, (0, 255, 255), False, pointlist0)
    pygame.draw.aalines(SURFACE, (255, 255, 0), False, pointlist1)
    pygame.display.update()
    FPSCLOCK.tick(30)
