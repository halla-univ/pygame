import sys, pygame
from pygame.locals import QUIT, Rect
pygame.init()
SURFACE = pygame.display.set_mode((400, 300))
FPSCLOCK = pygame.time.Clock()
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    SURFACE.fill((255, 255, 255))
    #그리기 코드 입력
    pygame.draw.rect(SURFACE,(0,0,255),(10,10,200,150))
    pygame.display.update()
    FPSCLOCK.tick(3)
