﻿msg = "Hello"

def say():
    global msg
    msg = "Hi"
    print("say:msg="+msg)
    obj_id = id(msg)
    print("say:id(msg)={0:d}".format(obj_id))

def main():
    say()
    print("main:msg="+msg)
    obj_id = id(msg)
    print("main:id(msg)={0:d}".format(obj_id))

main()
