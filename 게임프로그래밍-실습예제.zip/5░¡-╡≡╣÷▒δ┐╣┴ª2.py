﻿""" debug_test1.py """
def main():
    total = 0
    for index in range(100):
        total += index
    print(total)

if __name__ == '__main__':
    main()
