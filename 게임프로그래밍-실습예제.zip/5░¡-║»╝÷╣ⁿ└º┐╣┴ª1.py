﻿msg = "Hello" # 전역변수

def say():
    print("say:msg="+msg)
    obj_id = id(msg)
    print("say:id(msg)={0:d}".format(obj_id))

def main():
    say()
    print("main:msg="+msg)
    obj_id = id(msg)
    print("say:id(msg)={0:d}".format(obj_id))

main()
