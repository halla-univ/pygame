import pygame, pygame_menu  #모듈설치필수: pip install pygame_menu
pygame.init()
surface = pygame.display.set_mode((600, 400)) 

def level(self, value): #난이도 선택시 호출되는 함수
    print("난이도 선택값:", value)

def start(): # 게임시작 선택시 호출되는 함수
    print("게임시작")

t = pygame_menu.themes.THEME_BLUE; #블루테마 사용
t.widget_font=pygame.font.SysFont("gulim",30) #폰트:굴림체,30크기

menu = pygame_menu.Menu("Menu",400,300,theme=t) #메뉴윈도우 크기
menu.add.selector("난이도",[("Hard",1),("Easy",2)],onchange=level)
menu.add.button("게임 시작", start)
menu.add.button("게임 종료", pygame_menu.events.EXIT)
menu.mainloop(surface)
